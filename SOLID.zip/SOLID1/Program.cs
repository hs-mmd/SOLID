﻿namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("SOLID!");

            var logger = new ConsoleLogger();
            var storage = new ListStorageStrategy();
            var database = new Database(storage, logger);

            database.SaveData("Test Data", "TT");
            Console.WriteLine(database.RetrieveData(0));
        }
    }
}
