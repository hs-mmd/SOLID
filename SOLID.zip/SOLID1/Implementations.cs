using System;
using System.Collections.Generic;

namespace ConsoleApp1
{
    public class Database : IDatabase
    {
        private readonly IStorageStrategy _storageStrategy;
        private readonly ILogger _logger;

        public Database(IStorageStrategy storageStrategy, ILogger logger)
        {
            _storageStrategy = storageStrategy;
            _logger = logger;
        }

        public void SaveData(string input, string timestamp)
        {
            _storageStrategy.Store(input + "|" + timestamp);
            _logger.Log($"Data Saved: {input}|{timestamp}");
        }

        public string RetrieveData(int index)
        {
            try
            {
                return _storageStrategy.Retrieve(index);
            }
            catch (IndexOutOfRangeException)
            {
                _logger.Log("No data found for index.");
                throw;
            }
        }
    }

    public class ListStorageStrategy : IStorageStrategy
    {
        private readonly List<string> _data = new List<string>();

        public void Store(string data)
        {
            _data.Add(data);
        }

        public string Retrieve(int index)
        {
            if (index < 0 || index >= _data.Count)
                throw new IndexOutOfRangeException("Index out of range");

            return _data[index];
        }
    }

    public class ConsoleLogger : ILogger
    {
        public void Log(string message)
        {
            Console.WriteLine(message);
        }
    }

    public class SalaryCalculator : ISalaryCalculator
    {
        public string CalculateSalary(long userId)
        {
            return (userId * 100 + userId * 1000 - userId).ToString();
        }
    }

    public class AnimalSoundProvider : IAnimalSoundProvider
    {
        private readonly IDictionary<string, string> _animalSounds;

        public AnimalSoundProvider(IDictionary<string, string> animalSounds)
        {
            _animalSounds = animalSounds;
        }

        public string GetSound(string animal)
        {
            return _animalSounds.TryGetValue(animal, out var sound) ? sound : "UNKNOWN SOUND";
        }
    }

    public class AnimalManager
    {
        private readonly IEnumerable<string> _animals;
        private readonly IAnimalSoundProvider _soundProvider;

        public AnimalManager(IEnumerable<string> animals, IAnimalSoundProvider soundProvider)
        {
            _animals = animals;
            _soundProvider = soundProvider;
        }

        public void PrintAnimalSounds()
        {
            foreach (var animal in _animals)
            {
                Console.WriteLine($"Animal: {animal}, Sound: {_soundProvider.GetSound(animal)}");
            }
        }
    }

    public class SalaryProcessor
    {
        private readonly ISalaryCalculator _salaryCalculator;

        public SalaryProcessor(ISalaryCalculator salaryCalculator)
        {
            _salaryCalculator = salaryCalculator;
        }

        public string ProcessSalary(long userId)
        {
            return _salaryCalculator.CalculateSalary(userId);
        }
    }

    public class SalarySaver
    {
        private readonly IDatabase _database;

        public SalarySaver(IDatabase database)
        {
            _database = database;
        }

        public void SaveSalary(string salary, string note)
        {
            _database.SaveData(salary, note);
        }
    }

    public class SalaryManager
    {
        private readonly ISalaryCalculator _salaryCalculator;
        private readonly SalarySaver _salarySaver;

        public SalaryManager(ISalaryCalculator salaryCalculator, SalarySaver salarySaver)
        {
            _salaryCalculator = salaryCalculator;
            _salarySaver = salarySaver;
        }

        public void CalculateAndSaveSalary(User user, string note)
        {
            var salary = _salaryCalculator.CalculateSalary(user.Id);
            _salarySaver.SaveSalary(salary, note);
        }
    }

    public class User
    {
        public long Id { get; set; }
        public string? Email { get; set; }
    }

}
