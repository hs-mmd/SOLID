namespace ConsoleApp1
{
    public interface IDatabase
    {
        void SaveData(string input, string timestamp);
        string RetrieveData(int index);
    }

    public interface ILogger
    {
        void Log(string message);
    }

    public interface ISalaryCalculator
    {
        string CalculateSalary(long userId);
    }

    public interface IAnimalSoundProvider
    {
        string GetSound(string animal);
    }

    public interface IStorageStrategy
    {
        void Store(string data);
        string Retrieve(int index);
    }
}
