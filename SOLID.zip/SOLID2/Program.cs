﻿namespace ConsoleApp1
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            IUser buyer = new Buyer("Ali", "buyer");
            IUser seller = new Seller("Sara", "seller");
            IUser agent = new RealEstateAgent("John", "realestateagent");

            Property property = new Property("good house");

            IContentFilter contentFilter = new ProfanityContentFilter();

            IReviewService reviewService = new ReviewService(contentFilter);

            Feedback feedback = new Feedback(5, "Great! I had a good experience.", false);
            Review review = feedback.ConvertToReview();

            buyer.ProvideFeedback(feedback);
            reviewService.AddReview(property, review);

            reviewService.DisplayReviews(property);

            Feedback updatedFeedback = new Feedback(4, "I had a good experience but it could be better.", true);
            Review updatedReview = updatedFeedback.ConvertToReview();
            reviewService.EditReview(property, review, updatedReview);

            reviewService.DisplayReviews(property);
        }
    }

   

}
