namespace ConsoleApp1
{


    public class Property
    {
        public string PropertyName { get; set; }
        public List<Review> Reviews { get; set; }

        public Property(string propertyName)
        {
            PropertyName = propertyName;
            Reviews = new List<Review>();
        }

        public void AddReview(Review review)
        {
            Reviews.Add(review);
        }
    }

    public class Review
    {
        public int Rating { get; set; }
        public string Comment { get; set; }
        public bool IsAnonymous { get; set; }

        public Review(int rating, string comment, bool isAnonymous = false)
        {
            Rating = rating;
            Comment = comment;
            IsAnonymous = isAnonymous;
        }
    }

    public class Feedback
    {
        public int Rating { get; set; }
        public string Comment { get; set; }
        public bool IsAnonymous { get; set; }

        public Feedback(int rating, string comment, bool isAnonymous)
        {
            Rating = rating;
            Comment = comment;
            IsAnonymous = isAnonymous;
        }

        public Review ConvertToReview()
        {
            return new Review(Rating, Comment, IsAnonymous);
        }
    }
    public class ReviewService : IReviewService
    {
        private readonly IContentFilter _contentFilter;

        public ReviewService(IContentFilter contentFilter)
        {
            _contentFilter = contentFilter;
        }

        public void AddReview(Property property, Review review)
        {
            if (!_contentFilter.IsValidReview(review))
            {
                Console.WriteLine("bad content.");
                return;
            }

            property.AddReview(review);
            Console.WriteLine("comment added successfully.");
        }

        public void EditReview(Property property, Review oldReview, Review newReview)
        {
            if (!_contentFilter.IsValidReview(newReview))
            {
                Console.WriteLine("bad content.");
                return;
            }

            var reviewToEdit = property.Reviews.FirstOrDefault(r => r == oldReview);
            if (reviewToEdit != null)
            {
                reviewToEdit.Rating = newReview.Rating;
                reviewToEdit.Comment = newReview.Comment;
                reviewToEdit.IsAnonymous = newReview.IsAnonymous;
                Console.WriteLine("comment edited successfully.");
            }
        }

        public void DisplayReviews(Property property)
        {
            foreach (var review in property.Reviews)
            {
                Console.WriteLine($"score: {review.Rating} - comment: {review.Comment} - {(review.IsAnonymous ? "unknown" : "Its not unknown")}");
            }
        }
    }

    public class ProfanityContentFilter : IContentFilter
    {
        public bool IsValidReview(Review review)
        {
            if (review.Comment.Contains("fu.."))
            {
                return false;
            }
            return true;
        }
    }

    public class Buyer : IUser
    {
        public string Name { get; private set; }
        public string Role { get; private set; }

        public Buyer(string name, string role)
        {
            Name = name;
            Role = role;
        }

        public void ProvideFeedback(Feedback feedback)
        {
            Console.WriteLine($"{Name} as a {Role} Recorded feedback: {feedback.Comment}");
        }
    }

    public class Seller : IUser
    {
        public string Name { get; private set; }
        public string Role { get; private set; }

        public Seller(string name, string role)
        {
            Name = name;
            Role = role;
        }

        public void ProvideFeedback(Feedback feedback)
        {
            Console.WriteLine($"{Name} as a {Role} Recorded feedback: {feedback.Comment}");
        }
    }

    public class RealEstateAgent : IUser
    {
        public string Name { get; private set; }
        public string Role { get; private set; }

        public RealEstateAgent(string name, string role)
        {
            Name = name;
            Role = role;
        }

        public void ProvideFeedback(Feedback feedback)
        {
            Console.WriteLine($"{Name} as a {Role} Recorded feedback: {feedback.Comment}");
        }
    }

}