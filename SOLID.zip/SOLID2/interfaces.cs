namespace ConsoleApp1
{

    public interface IUser
    {
        string Name { get; }
        string Role { get; }
        void ProvideFeedback(Feedback feedback);
    }

    public interface IReviewService
    {
        void AddReview(Property property, Review review);
        void EditReview(Property property, Review oldReview, Review newReview);
        void DisplayReviews(Property property);
    }

    public interface IContentFilter
    {
        bool IsValidReview(Review review);
    }

}